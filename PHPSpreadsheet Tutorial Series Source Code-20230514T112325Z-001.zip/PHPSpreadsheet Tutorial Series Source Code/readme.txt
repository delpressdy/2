first, download and extract phpspreadsheet_chapter_1.zip.
that zip file contains the library and the source code for chapter 1.
then you can download the script you need.